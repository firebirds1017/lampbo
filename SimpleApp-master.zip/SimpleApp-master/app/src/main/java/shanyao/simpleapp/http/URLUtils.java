package shanyao.simpleapp.http;

/**
 * Created by zs on 2016/3/25.
 */
public interface URLUtils {
    String BASE_URL = "http://115.28.209.219:8080/parking-app-client-1.0";
    String BASE_URL1 = BASE_URL + "/";
    String SHARE_CARPORT1 = "android/newApi/shareSpaceApi/shareList";// 共享车位
}

