package com.example.zhangyipeng.anwerdemo.bean;

import java.util.List;

/**
 * Created by zhangyipeng on 16/7/27.
 */
public class QuestionList {
    private List<QuestionEntry> questionList;

    public List<QuestionEntry> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(List<QuestionEntry> questionList) {
        this.questionList = questionList;
    }
}
