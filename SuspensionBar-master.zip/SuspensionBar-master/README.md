# SuspensionBar
A RecyclerView suspension bar implementation like Instagram

相关博客地址：[Android轻松实现RecyclerView悬浮条](http://www.jianshu.com/p/fe69a53502ab)

![](https://github.com/wuapnjie/SuspensionBar/blob/master/art/SuspensionBar.gif)
