package com.example.zhangyipeng.anwerdemo.bean;

/**
 * Created by zhangyipeng on 16/6/30.
 */
public class BaseInfo {

    /**
     * code : 0
     * success : true
     * msg :
     */

    private int code;
    private String success;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
