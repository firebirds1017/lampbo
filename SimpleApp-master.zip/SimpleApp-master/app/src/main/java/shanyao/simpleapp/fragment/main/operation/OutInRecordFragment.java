package shanyao.simpleapp.fragment.main.operation;

import android.view.View;
import android.view.ViewGroup;

import shanyao.simpleapp.fragment.BaseListFragment;


/**
 * Created by zs on 2016/5/9.
 */
public class OutInRecordFragment extends BaseListFragment {
    /**
     * 在这个方法请求服务器数据
     */
    @Override
    protected Object requestData() {
        return null;
    }
    /**
     * 这个方法相当于BaseAdapter的getView方法
     */
    @Override
    protected View setView(int position, View convertView, ViewGroup parent) {
        return null;
    }
    /**
     * 刷新操作
     */
    @Override
    protected void setRefresh() {

    }
    /**
     * 加载更多操作
     */
    @Override
    protected void loadMore() {

    }

    /**
     * 设置actionBar
     */
    @Override
    protected void setActionBar() {

    }

    @Override
    public void onClick(View v) {

    }
}
