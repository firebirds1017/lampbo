//
//  AppDelegate.h
//  iconFontDemo
//
//  Created by liyang@l2cplat.com on 16/9/9.
//  Copyright © 2016年 yang_li828@163.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

